import java.util.ArrayList;
import java.util.Scanner;
public class userBalance {

    Scanner input = new Scanner(System.in);

//Stored values transferred from user login to keep track of who's currently using balance
    ArrayList<Integer> usersBalance = new ArrayList<Integer>();
    ArrayList<String> balanceUsername = new ArrayList<String>();
    ArrayList<Integer> currentChoice = new ArrayList<Integer>();

    public userBalance(ArrayList<String> listOfEmails, ArrayList<Integer> userChoice) {
        balanceUsername.addAll(listOfEmails);
        currentChoice.addAll(userChoice);
    }
//Everytime a new user is created, user is given £0
    public void setStartingBalance() {
        if (3 <= usersBalance.size()) {
            usersBalance.add(0);
            usersBalance.remove(0);
        } else {
            usersBalance.add(0);
        }
    }
//Presents the user with their current balance
    public void getCurrentUserBalance(ArrayList<String> balanceUsername, ArrayList<Integer> userChoice) {
        int currentUserChoice = userChoice.get(0);
        if (currentUserChoice == 0) {
            System.out.println(balanceUsername.get(0));
            System.out.println("Current Balance : £" + usersBalance.get(0));
        } else {
            if (currentUserChoice == 1) {
                System.out.println(balanceUsername.get(1));
                System.out.println("Current Balance : £" + usersBalance.get(1));
            } else {
                System.out.println(balanceUsername.get(2));
                System.out.println("Current Balance : £" + usersBalance.get(2));
            }
        }
    }
    // First choice user makes is 1.deposit, 2.withdraw, 3.transfer, 4.log out
    // Second choice relies on the user picking 3.transfer, once user has chosen this option they make a choice between
    //who to transfer their money to
    public void getDepositWithdrawTransferToUserBalance(ArrayList<String> balanceUsername, ArrayList<Integer> userChoice) {
        int currentUserChoice = userChoice.get(0);
        while(true) {
            System.out.println("-------------------------------------");
            System.out.println("Deposit, Withdraw, Transfer, Log Out");
            System.out.println("Pick 1, 2, 3, 4 : ");
            int choice = input.nextInt();
            if(choice == 1) {
                System.out.println("How much would you like to deposit? : ");
                int depositAmount = input.nextInt();
                int newCurrentBalance = usersBalance.get(currentUserChoice) + depositAmount;
                usersBalance.set(currentUserChoice, newCurrentBalance);
                System.out.println("Deposit successful! : ");
                System.out.println(balanceUsername.get(currentUserChoice));
                System.out.println("Current Balance : £" + newCurrentBalance);
            }
            if(choice == 2) {
                System.out.println("How much would you like to withdraw? : ");
                int depositAmount = input.nextInt();
                int newCurrentBalance = usersBalance.get(currentUserChoice) - depositAmount;
                usersBalance.set(currentUserChoice, newCurrentBalance);
                System.out.println("Withdraw successful! : ");
                System.out.println(balanceUsername.get(currentUserChoice));
                System.out.println("Current Balance : £" + newCurrentBalance);
            } if(choice == 3) {
                while(true) {
                    System.out.println("Current Users : " + balanceUsername);
                    System.out.println("Pick 1. 2. 3. : ");
                    int transferChoice = input.nextInt();
                    if (transferChoice == 1) {
                        System.out.println("How much would you like to transfer to " + balanceUsername.get(0) + "?");
                        int transferAmount = input.nextInt();
                        int newCurrentBalance = usersBalance.get(currentUserChoice) - transferAmount;
                        usersBalance.set(currentUserChoice, newCurrentBalance);
                        int newOtherUserCurrentBalance = usersBalance.get(transferChoice - 1) + transferAmount;
                        usersBalance.set(transferChoice - 1, newOtherUserCurrentBalance);
                        System.out.println("Transfer was succesful! : ");
                        System.out.println(balanceUsername.get(currentUserChoice));
                        System.out.println("Current Balance : £" + newCurrentBalance);
                    }
                    if (transferChoice == 2 && usersBalance.size() == 2) {
                        System.out.println("How much would you like to transfer to " + balanceUsername.get(1) + "?");
                        int transferAmount = input.nextInt();
                        int newCurrentBalance = usersBalance.get(currentUserChoice) - transferAmount;
                        usersBalance.set(currentUserChoice, newCurrentBalance);
                        int newOtherUserCurrentBalance = usersBalance.get(transferChoice - 1) + transferAmount;
                        usersBalance.set(transferChoice - 1, newOtherUserCurrentBalance);
                        System.out.println("Transfer was successful! : ");
                        System.out.println(balanceUsername.get(currentUserChoice));
                        System.out.println("Current Balance : £" + newCurrentBalance);
                    }
                    if (transferChoice == 3 && usersBalance.size() == 3) {
                        System.out.println("How much would you like to transfer to " + balanceUsername.get(2) + "?");
                        int transferAmount = input.nextInt();
                        int newCurrentBalance = usersBalance.get(currentUserChoice) - transferAmount;
                        usersBalance.set(currentUserChoice, newCurrentBalance);
                        int newOtherUserCurrentBalance = usersBalance.get(transferChoice - 1) + transferAmount;
                        usersBalance.set(transferChoice - 1, newOtherUserCurrentBalance);
                        System.out.println("Transfer was succesful! : ");
                        System.out.println(balanceUsername.get(currentUserChoice));
                        System.out.println("Current Balance : £" + newCurrentBalance);
                    } break;
                }
            } else if (choice == 4) { break; }
        }
    }
}








