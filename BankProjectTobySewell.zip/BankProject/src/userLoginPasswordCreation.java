import java.util.ArrayList;
import java.util.Scanner;
public class userLoginPassword {
    //Holds user details in array to be then transferred to user login and user balance
    ArrayList<String> user1LoginPassword = new ArrayList<String>();
    ArrayList<String> user2LoginPassword = new ArrayList<String>();
    ArrayList<String> user3LoginPassword = new ArrayList<String>();
    Scanner input = new Scanner(System.in);

    //Asks and adds relevant user details to user1 array
    public void addUserDetailsToArray() {
        System.out.println("Create an username : ");
        String username = input.next();
        user1LoginPassword.add(username);
        System.out.println("Create a password : ");
        String password = input.next();
        user1LoginPassword.add(password);
        System.out.println("What's your full name and title? : ");
        String name = input.nextLine();
        input.nextLine();
        user1LoginPassword.add(name);
        input.reset();
        while (true) {
            System.out.println("Client, Community, Small Business Account");
            System.out.println("Pick 1, 2, 3");
            int choice = input.nextInt();
            if(choice == 1) {
                user1LoginPassword.add("Client Account (Overdraft £1000)");
                user1LoginPassword.add("");
            } else {
                if (choice == 2) {
                    user1LoginPassword.add("Community Account (Overdraft £1500)");
                    System.out.println("Enter signatory full name and title : ");
                    String var = input.nextLine();
                    user1LoginPassword.add(input.nextLine());
                } else {
                    if (choice == 3) {
                        user1LoginPassword.add("Small Business Account (Overdraft £2500)");
                        System.out.println("Enter signatory full name and title : ");
                        String var = input.nextLine();
                        user1LoginPassword.add(input.nextLine());
                    }
                }
            } break;
        }
    }
    //When a new user is created it replaces the oldest user in the array. It does this by clearing room
    //From array 2, 3 and transfers those user details between arrays. This is FUNDAMENTAL for the rest
    public void clearUser1LoginPassword() {
        user3LoginPassword.clear();
        user3LoginPassword.addAll(user2LoginPassword);
        user2LoginPassword.clear();
        user2LoginPassword.addAll(user1LoginPassword); // Transfer values to user2LoginPassword
        user1LoginPassword.clear(); // Clear user1LoginPassword for new input
    }
}

