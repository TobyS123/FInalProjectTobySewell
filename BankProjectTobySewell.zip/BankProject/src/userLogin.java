import java.util.ArrayList;
import java.util.Scanner;

public class userLogin {

    Scanner input = new Scanner(System.in);
    //Keeps track of user account creation details in rotation of size.(3) users. Account details size.(9) but
    // still keeps on rotation of 3 users since it's a sum of 3
    ArrayList<String> listOfEmails = new ArrayList<String>();
    ArrayList<String> listOfPasswords = new ArrayList<String>();
    ArrayList<String> listOfAccountDetails = new ArrayList<String>();

    //Transferred user account creation details array list
    ArrayList<String> tempEmailPassword = new ArrayList<String>();
    ArrayList<String> tempCurrentEmail = new ArrayList<String>();
    ArrayList<String> tempCurrentPassword = new ArrayList<String>();
    ArrayList<String> tempCurrentAccountDetails = new ArrayList<String>();
    ArrayList<Integer> userChoice = new ArrayList<Integer>();
    ArrayList<String> user1Signatories = new ArrayList<String>();

// Prepares class for new user, precaution out of bounds array error when using array util methods
    public userLogin(ArrayList<String> user1LoginPassword) {
        // Initialize tempLoginPassword with the provided ArrayList
        tempEmailPassword.addAll(user1LoginPassword);
        tempCurrentEmail.add("");
        tempCurrentPassword.add("");
        tempCurrentAccountDetails.add("");
        tempCurrentAccountDetails.add("");
        tempCurrentAccountDetails.add("");
    }
// Gives user choice from available users. From the choices made here we extract other various details from lists we've
//stored to keep track of who's currently logged in. Whoever is logged in their details are stored in tempCurrent...
    public void userAskEmail() {
        System.out.println("Current Users : " + listOfEmails);
        System.out.println("Pick 1. 2. 3.");
        int choice = input.nextInt();
        if (choice == 1) {
            tempCurrentEmail.remove(0);
            tempCurrentEmail.add(listOfEmails.get(0));
            tempCurrentPassword.remove(0);
            tempCurrentPassword.add(listOfPasswords.get(0));
            tempCurrentAccountDetails.clear();
            tempCurrentAccountDetails.add(listOfAccountDetails.get(0));
            tempCurrentAccountDetails.add(listOfAccountDetails.get(1));
            tempCurrentAccountDetails.add(listOfAccountDetails.get(2));
            userChoice.clear();
            userChoice.add(0);
        } else if (choice == 2) {
            tempCurrentEmail.remove(0);
            tempCurrentEmail.add(listOfEmails.get(1));
            tempCurrentPassword.remove(0);
            tempCurrentPassword.add(listOfPasswords.get(1));
            tempCurrentAccountDetails.clear();
            tempCurrentAccountDetails.add(listOfAccountDetails.get(3));
            tempCurrentAccountDetails.add(listOfAccountDetails.get(4));
            tempCurrentAccountDetails.add(listOfAccountDetails.get(5));
            userChoice.clear();
            userChoice.add(1);
        } else {
            tempCurrentEmail.remove(0);
            tempCurrentEmail.add(listOfEmails.get(2));
            tempCurrentPassword.remove(0);
            tempCurrentPassword.add(listOfPasswords.get(2));
            tempCurrentAccountDetails.clear();
            tempCurrentAccountDetails.add(listOfAccountDetails.get(6));
            tempCurrentAccountDetails.add(listOfAccountDetails.get(7));
            tempCurrentAccountDetails.add(listOfAccountDetails.get(8));
            userChoice.clear();
            userChoice.add(2);
        }
    }
//User is then asked from password. Based on user choice they are required to enter the correct password in order
    //to login
    public void userAskPassword() {
        String correctPassword = tempCurrentPassword.get(0);
        System.out.println(correctPassword);
        while(true) {
            System.out.println("Enter your password : ");
            String enteredPassword = input.next();
            if(enteredPassword.equals(correctPassword)) {
                System.out.println("!LOGIN SUCCESSFUL!");
                System.out.println(tempCurrentAccountDetails.get(0));
                System.out.println(tempCurrentAccountDetails.get(1));
                System.out.println("Signatories " + "(" + tempCurrentAccountDetails.get(2) + ")");
                break;
            } else {
                System.out.println("!INCORRECT PASSWORD!");
            }
        }
    }
//Reset state for when a new account is created
    public void resetLoginState(ArrayList<String> newLoginPassword) {
        tempEmailPassword.clear();
        tempEmailPassword.addAll(newLoginPassword);
        user1Signatories.clear();
        // Any other state that needs to be reset
    }
    //Keeps track of new users in 3 separate lists that then interacts with various methods
    public void otherUsersEmailsPasswords() {
        if(3 <= listOfEmails.size()) {
            listOfPasswords.add(tempEmailPassword.get(1));
            listOfPasswords.remove(0);
            listOfEmails.add(tempEmailPassword.get(0));
            listOfEmails.remove(0);
            listOfAccountDetails.add(tempEmailPassword.get(2));
            listOfAccountDetails.add(tempEmailPassword.get(3));
            listOfAccountDetails.add(tempEmailPassword.get(4));
            listOfAccountDetails.remove(0);
            listOfAccountDetails.remove(1);
            listOfAccountDetails.remove(2);
            System.out.println(listOfEmails);
        } else {
            listOfPasswords.add(tempEmailPassword.get(1));
            listOfEmails.add(tempEmailPassword.get(0));
            listOfAccountDetails.add(tempEmailPassword.get(2));
            listOfAccountDetails.add(tempEmailPassword.get(3));
            listOfAccountDetails.add(tempEmailPassword.get(4));
            System.out.println(listOfEmails);
        }
    }
}

