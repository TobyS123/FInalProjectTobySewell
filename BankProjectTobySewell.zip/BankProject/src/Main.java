import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        userLoginPassword uLP = new userLoginPassword();
        userLogin uL = new userLogin(uLP.user1LoginPassword);
        userBalance uB = new userBalance(uL.listOfEmails, uL.userChoice);

        int i = 0;
        //Loop, user either picks login or sign up.
        while (true) {
            System.out.println("Login, Sign Up");
            System.out.println("Pick 1, 2");
            int choice = input.nextInt();
            if (choice == 1 && i == 1) {
                uL.userAskEmail();
                uL.userAskPassword();
                uB.getCurrentUserBalance(uL.listOfEmails, uL.userChoice);
                uB.getDepositWithdrawTransferToUserBalance(uL.listOfEmails, uL.userChoice);
            } else {
                if (choice == 2) {
                    uLP.addUserDetailsToArray();
                    uL.resetLoginState(uLP.user1LoginPassword);
                    uL.otherUsersEmailsPasswords();
                    uB.setStartingBalance();
                    uL.userAskEmail();
                    uL.userAskPassword();
                    uB.getCurrentUserBalance(uL.listOfEmails, uL.userChoice);
                    uB.getDepositWithdrawTransferToUserBalance(uL.listOfEmails, uL.userChoice);
                    uLP.clearUser1LoginPassword();
                    i++;
                }
            }
        }
    }
}

